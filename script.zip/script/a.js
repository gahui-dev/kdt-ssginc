// a.js

export function fun() {
  console.log("a.js >> fun");
}

