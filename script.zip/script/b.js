// b.js

export function fun2() {
  console.log("b.js >> fun2");
}

export class Person {
  
}

